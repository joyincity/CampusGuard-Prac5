
#include "CampusControlServer.h"
#include "ServerManager.h"

#include "Fire.h"
#include "SecurityThreat.h"
#include "EmergencyChannel.h"
#include "MedicalTeam.h"
#include "SecurityTeam.h"
#include "CommunicationService.h"   // ← the Adapter

#include "OperationsDashboard.h"
#include "DispatchUnit.h"
#include "Evacuate.h"
#include "CancelAction.h"

#include <iostream>

int main() {
    std::cout << "============================================\n";
    std::cout << "   CampusGuard - Multi-Incident Demo\n";
    std::cout << "   (with CommunicationService adapter)\n";
    std::cout << "============================================\n";

    // ─────────────────────────────────────────────
    // SUBSYSTEMS
    // ─────────────────────────────────────────────
    EmergencyChannel* channel = new EmergencyChannel();
    ServerManager     manager;   // stack — owned by main

    CampusControlServer* campusControl =
        new CampusControlServer(channel, &manager);

    // ─────────────────────────────────────────────
    // INCIDENTS
    // ─────────────────────────────────────────────
    Incident* fire   = new Fire(channel, 1, 3);            // incident 1, area 3
    Incident* threat = new SecurityThreat(channel, 2, 7);  // incident 2, area 7

    // ─────────────────────────────────────────────
    // UNITS: 2 medical, 2 security, 1 comms adapter
    // ─────────────────────────────────────────────
    Unit* medA  = new MedicalTeam(channel);
    Unit* medB  = new MedicalTeam(channel);
    Unit* secA  = new SecurityTeam(channel);
    Unit* secB  = new SecurityTeam(channel);
    Unit* comms = new CommunicationService(channel);   // ← the Adapter

    OperationsDashboard dashboard;

    // ─────────────────────────────────────────────
    // REPORT BOTH INCIDENTS
    // ─────────────────────────────────────────────
    std::cout << "\n──── Reporting both incidents ────\n";
    fire->advanceStatus();     // Started → Reported
    threat->advanceStatus();

    fire->print();
    threat->print();

    std::cout << "\nAdapter state after reporting:\n";
    comms->print();

    // ─────────────────────────────────────────────
    // COMMAND 1: Dispatch incident 1
    // ─────────────────────────────────────────────
    std::cout << "\n──── Command: Dispatch incident 1 (Fire, area 3) ────\n";
    OperationAction* dispatchFire = new DispatchUnit(channel, fire);
    dashboard.setCommand(dispatchFire);
    dashboard.executeCommand();

    std::cout << "\nUnit state after dispatching incident 1:\n";
    medA->print();
    medB->print();
    secA->print();
    secB->print();
    comms->print();   // ← now shows FireDepartment is dispatched

    // ─────────────────────────────────────────────
    // COMMAND 2: Dispatch incident 2
    // ─────────────────────────────────────────────
    std::cout << "\n──── Command: Dispatch incident 2 (SecurityThreat, area 7) ────\n";
    OperationAction* dispatchThreat = new DispatchUnit(channel, threat);
    dashboard.setCommand(dispatchThreat);
    dashboard.executeCommand();

    std::cout << "\nUnit state after dispatching incident 2:\n";
    medA->print();
    medB->print();
    secA->print();
    secB->print();
    comms->print();

    // ─────────────────────────────────────────────
    // COMMAND 3: Evacuate area 7
    // ─────────────────────────────────────────────
    std::cout << "\n──── Command: Evacuate area 7 ────\n";
    dashboard.setCommand(new Evacuate(channel, threat));
    dashboard.executeCommand();

    // ─────────────────────────────────────────────
    // COMMAND 4: Cancel incident 1's dispatch
    // ─────────────────────────────────────────────
    std::cout << "\n──── Command: Cancel incident 1's dispatch ────\n";
    CancelAction* cancelFire = new CancelAction(dispatchFire);
    dashboard.setCommand(cancelFire);
    dashboard.executeCommand();

    std::cout << "\nUnit state after cancelling incident 1:\n";
    medA->print();
    medB->print();
    secA->print();
    secB->print();
    comms->print();

    // ─────────────────────────────────────────────
    // FAILURE: Cancel incident 1 again
    // ─────────────────────────────────────────────
    std::cout << "\n──── Failure: Cancel incident 1 again ────\n";
    dashboard.setCommand(new CancelAction(dispatchFire));
    dashboard.executeCommand();

    // ─────────────────────────────────────────────
    // COMMAND 5: Undo the cancel
    // ─────────────────────────────────────────────
    std::cout << "\n──── Command: Undo the cancel ────\n";
    cancelFire->undo();

    std::cout << "\nUnit state after undoing the cancel:\n";
    medA->print();
    medB->print();
    secA->print();
    secB->print();
    comms->print();

    // ─────────────────────────────────────────────
    // FAILURE: Undo again
    // ─────────────────────────────────────────────
    std::cout << "\n──── Failure: Undo the cancel again ────\n";
    cancelFire->undo();

    // ─────────────────────────────────────────────
    // COMMAND 6: Cancel incident 2's dispatch
    // ─────────────────────────────────────────────
    std::cout << "\n──── Command: Cancel incident 2's dispatch ────\n";
    CancelAction* cancelThreat = new CancelAction(dispatchThreat);
    dashboard.setCommand(cancelThreat);
    dashboard.executeCommand();

    std::cout << "\nFinal unit state:\n";
    medA->print();
    medB->print();
    secA->print();
    secB->print();
    comms->print();

    // ─────────────────────────────────────────────
    // CAMPUS STATE
    // ─────────────────────────────────────────────
    std::cout << "\n──── Campus state ────\n";
    campusControl->print();

    // ─────────────────────────────────────────────
    // MEMENTO RESTORE
    // ─────────────────────────────────────────────
    std::cout << "\n──── Memento: Restore from latest snapshot ────\n";
    if (!manager.isEmpty()) {
        std::cout << "[Memento] Restoring...\n";
        campusControl->setRestorePoint(manager.getLatestRP());
        manager.removeLatestRP();
    } else {
        std::cout << "[Memento] No snapshot available\n";
    }
    campusControl->print();

    // ─────────────────────────────────────────────
    // CLEANUP
    // ─────────────────────────────────────────────
    std::cout << "\n──── Cleanup ────\n";
    delete comms;
    delete medA;
    delete medB;
    delete secA;
    delete secB;
    delete fire;
    delete threat;
    delete campusControl;   // does NOT own manager
    delete channel;

    std::cout << "\nDemo complete.\n";
    return 0;
}